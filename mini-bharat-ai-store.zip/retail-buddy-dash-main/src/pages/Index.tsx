import { useState } from "react";
import { Navigation } from "@/components/Navigation";
import { ChatInterface } from "@/components/ChatInterface";
import { Dashboard } from "@/components/Dashboard";

const Index = () => {
  const [activeTab, setActiveTab] = useState<'chat' | 'dashboard'>('chat');

  return (
    <div className="min-h-screen bg-background">
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
      <div className="h-[calc(100vh-80px)]">
        {activeTab === 'chat' ? <ChatInterface /> : <Dashboard />}
      </div>
    </div>
  );
};

export default Index;
