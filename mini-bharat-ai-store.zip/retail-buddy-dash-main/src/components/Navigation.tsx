import { Button } from "@/components/ui/button";
import { MessageCircle, BarChart3 } from "lucide-react";
import { cn } from "@/lib/utils";

interface NavigationProps {
  activeTab: 'chat' | 'dashboard';
  onTabChange: (tab: 'chat' | 'dashboard') => void;
}

export const Navigation = ({ activeTab, onTabChange }: NavigationProps) => {
  return (
    <div className="flex justify-center p-4 bg-background border-b border-border">
      <div className="flex bg-secondary rounded-lg p-1">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onTabChange('chat')}
          className={cn(
            "flex items-center gap-2 px-4 py-2 rounded-md transition-all",
            activeTab === 'chat'
              ? "bg-primary text-primary-foreground shadow-sm"
              : "text-muted-foreground hover:text-foreground"
          )}
        >
          <MessageCircle className="h-4 w-4" />
          Chat Assistant
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onTabChange('dashboard')}
          className={cn(
            "flex items-center gap-2 px-4 py-2 rounded-md transition-all",
            activeTab === 'dashboard'
              ? "bg-primary text-primary-foreground shadow-sm"
              : "text-muted-foreground hover:text-foreground"
          )}
        >
          <BarChart3 className="h-4 w-4" />
          Dashboard
        </Button>
      </div>
    </div>
  );
};