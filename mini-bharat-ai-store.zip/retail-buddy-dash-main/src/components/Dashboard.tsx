import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  TrendingUp, 
  AlertTriangle, 
  DollarSign, 
  MapPin,
  Package,
  Truck,
  CreditCard,
  BarChart
} from "lucide-react";
import { 
  transactions, 
  inventory, 
  logistics, 
  offers,
  getDemandForecast,
  getExpiryAlerts,
  getCreditScore 
} from "@/data/mockData";

export const Dashboard = () => {
  const demandForecast = getDemandForecast();
  const expiryAlerts = getExpiryAlerts();
  const creditScore = getCreditScore('R001');
  
  // Calculate total revenue
  const totalRevenue = transactions.reduce((sum, t) => sum + t.amount, 0);
  
  // Calculate inventory value
  const inventoryValue = inventory.reduce((sum, item) => sum + (item.stock * item.price), 0);

  return (
    <div className="p-6 space-y-6 bg-background min-h-screen">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2">Retail Dashboard</h1>
        <p className="text-muted-foreground">Monitor your FMCG business performance and insights</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-dashboard-card border-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-card-foreground">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-card-foreground">₹{totalRevenue.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">+12% from last month</p>
          </CardContent>
        </Card>

        <Card className="bg-dashboard-card border-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-card-foreground">Inventory Value</CardTitle>
            <Package className="h-4 w-4 text-info" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-card-foreground">₹{inventoryValue.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">{inventory.length} unique products</p>
          </CardContent>
        </Card>

        <Card className="bg-dashboard-card border-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-card-foreground">Credit Score</CardTitle>
            <CreditCard className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-card-foreground">{creditScore}/850</div>
            <p className="text-xs text-success">Excellent rating</p>
          </CardContent>
        </Card>

        <Card className="bg-dashboard-card border-border">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-card-foreground">Active Deliveries</CardTitle>
            <Truck className="h-4 w-4 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-card-foreground">
              {logistics.filter(l => l.status !== 'delivered').length}
            </div>
            <p className="text-xs text-muted-foreground">2 in transit, 1 pending</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts and Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Demand Forecasting */}
        <Card className="bg-dashboard-card border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-card-foreground">
              <TrendingUp className="h-5 w-5 text-primary" />
              Demand Forecasting
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {demandForecast.map((item, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg">
                  <div>
                    <p className="font-medium text-card-foreground">{item.product}</p>
                    <p className="text-sm text-muted-foreground">Avg: {item.avgDemand.toFixed(0)} units</p>
                  </div>
                  <Badge variant={item.trend === 'up' ? 'default' : 'secondary'}>
                    {item.trend === 'up' ? '↗️' : '↘️'} {item.trend}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Expiry Alerts */}
        <Card className="bg-dashboard-card border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-card-foreground">
              <AlertTriangle className="h-5 w-5 text-warning" />
              Expiry Alerts
            </CardTitle>
          </CardHeader>
          <CardContent>
            {expiryAlerts.length > 0 ? (
              <div className="space-y-3">
                {expiryAlerts.map((item) => (
                  <div key={item.id} className="flex items-center justify-between p-3 bg-warning/10 rounded-lg border border-warning/20">
                    <div>
                      <p className="font-medium text-card-foreground">{item.product}</p>
                      <p className="text-sm text-muted-foreground">Stock: {item.stock} units</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-warning">{item.expiryDate}</p>
                      <p className="text-xs text-muted-foreground">
                        {Math.ceil((new Date(item.expiryDate).getTime() - new Date().getTime()) / (1000 * 3600 * 24))} days left
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-center py-8">No products expiring soon ✅</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Pricing and Route Optimization */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pricing Comparison */}
        <Card className="bg-dashboard-card border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-card-foreground">
              <BarChart className="h-5 w-5 text-info" />
              Active Offers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {offers.map((offer) => (
                <div key={offer.id} className="flex items-center justify-between p-3 bg-success/10 rounded-lg border border-success/20">
                  <div>
                    <p className="font-medium text-card-foreground">{offer.product}</p>
                    <p className="text-sm text-muted-foreground">{offer.category}</p>
                  </div>
                  <div className="text-right">
                    <Badge className="bg-success text-success-foreground">
                      {offer.discount}% OFF
                    </Badge>
                    <p className="text-xs text-muted-foreground mt-1">Until {offer.validUntil}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Route Optimization */}
        <Card className="bg-dashboard-card border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-card-foreground">
              <MapPin className="h-5 w-5 text-primary" />
              Logistics Overview
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {logistics.map((booking) => (
                <div key={booking.id} className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg">
                  <div>
                    <p className="font-medium text-card-foreground">{booking.route}</p>
                    <p className="text-sm text-muted-foreground">{booking.vehicle} • {booking.distance}km</p>
                  </div>
                  <Badge 
                    variant={
                      booking.status === 'delivered' ? 'default' : 
                      booking.status === 'in_transit' ? 'secondary' : 'outline'
                    }
                  >
                    {booking.status.replace('_', ' ')}
                  </Badge>
                </div>
              ))}
            </div>
            <div className="mt-4 p-3 bg-info/10 rounded-lg border border-info/20">
              <p className="text-sm text-card-foreground font-medium">Optimization Tip:</p>
              <p className="text-xs text-muted-foreground">
                Combine deliveries to Zone A & B to save 15% on fuel costs
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};