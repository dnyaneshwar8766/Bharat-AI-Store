import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ChatBubble } from "./ChatBubble";
import { Send } from "lucide-react";
import { getCreditScore, getExpiryAlerts, inventory, logistics, deliveries } from "@/data/mockData";

interface Message {
  id: string;
  message: string;
  isUser: boolean;
  timestamp: string;
}

const initialMessages: Message[] = [
  {
    id: '1',
    message: 'Hello! I\'m your FMCG Retail Assistant. I can help you with inventory, deliveries, credit scores, and more. How can I assist you today?',
    isUser: false,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  }
];

export const ChatInterface = () => {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [inputValue, setInputValue] = useState('');

  const generateResponse = (userMessage: string): string => {
    const message = userMessage.toLowerCase();
    
    // INVENTORY
    if (message.includes('stock') || message.includes('inventory')) {
      const totalItems = inventory.reduce((sum, item) => sum + item.stock, 0);
      return `You have ${totalItems} total items in stock across ${inventory.length} products. Your top products are: ${inventory.slice(0, 3).map(item => `${item.product} (${item.stock} units)`).join(', ')}.`;
    }
    
    if (message.includes('deduct') && message.includes('maggi')) {
      return '✅ Deducted 20 units of Maggi Noodles. Remaining stock: 180 units.';
    }
    
    // EXPIRY
    if (message.includes('expiry') || message.includes('expire') || message.includes('expiring')) {
      const alerts = getExpiryAlerts();
      if (alerts.length > 0) {
        return `⚠️ Alert: ${alerts.length} products expiring soon:\n${alerts.map(item => `- ${item.product} (${item.expiryDate})`).join('\n')}`;
      }
      return 'No products are expiring in the next 7 days. Your inventory is well-managed!';
    }
    
    // DELIVERY/LOGISTICS
    if (message.includes('book') && (message.includes('truck') || message.includes('bike'))) {
      const vehicleType = message.includes('truck') ? 'truck' : 'bike';
      const destination = message.includes('pune') ? 'Pune' : 
                        message.includes('delhi') ? 'Delhi' : 
                        message.includes('shivajinagar') ? 'Shivajinagar' :
                        message.includes('local') ? 'Local Zone' : 'Pune';
      
      if (vehicleType === 'truck') {
        const trackingId = `DL${Math.floor(Math.random() * 9000) + 1000}`;
        return `✅ Truck booked successfully!\nTracking ID: ${trackingId}\nDestination: ${destination}\nETA: 6 hours\nCost: ₹3,500`;
      } else {
        const trackingId = `DL${Math.floor(Math.random() * 9000) + 1000}`;
        return `✅ Bike booked successfully!\nTracking ID: ${trackingId}\nDestination: ${destination}\nETA: 45 mins\nCost: ₹150`;
      }
    }
    
    if (message.includes('delivery status') || (message.includes('status') && message.includes('delivery'))) {
      return '📦 Delivery ID DL1234 is in transit. ETA: 3 hours.';
    }
    
    if (message.includes('delivery') || message.includes('logistics')) {
      const activeDeliveries = logistics.filter(l => l.status !== 'delivered').length;
      return `You have ${activeDeliveries} active deliveries. Say "book truck for pune" or "book bike for delivery" to book new deliveries!`;
    }
    
    // CREDIT
    if (message.includes('credit score') || (message.includes('credit') && message.includes('score'))) {
      const score = getCreditScore('R001');
      return `Your current credit score is ${score} (${score > 700 ? 'Good' : 'Average'}). You are eligible for 15-day credit up to ₹50,000.`;
    }
    
    if (message.includes('outstanding') || message.includes('payment') || message.includes('due')) {
      return '📊 Outstanding payments: ₹12,500 due on 20 Dec 2024.';
    }
    
    if (message.includes('credit')) {
      const score = getCreditScore('R001');
      return `Your current credit score is ${score}/850. ${score > 700 ? 'Excellent! You\'re eligible for premium credit terms.' : 'Good score! You can improve it by maintaining timely payments.'}`;
    }
    
    // PRICING/OFFERS
    if (message.includes('price') || message.includes('offer')) {
      return 'Current active offers: Coca Cola 15% off, Maggi Noodles 20% off, Tide Detergent 10% off. These offers can help move inventory faster!';
    }
    
    // FALLBACK
    return 'I can help you with inventory, delivery tracking, credit scores, expiry alerts, and pricing offers. Please specify what you\'d like to know more about!';
  };

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      message: inputValue,
      isUser: true,
      timestamp
    };
    
    setMessages(prev => [...prev, userMessage]);
    
    // Generate and add bot response
    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        message: generateResponse(inputValue),
        isUser: false,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      
      setMessages(prev => [...prev, botResponse]);
    }, 1000);
    
    setInputValue('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  return (
    <div className="flex flex-col h-full bg-chat-background">
      {/* Header */}
      <div className="bg-primary p-4 text-primary-foreground">
        <h2 className="text-lg font-semibold">FMCG Retail Assistant</h2>
        <p className="text-sm opacity-90">Online now</p>
      </div>
      
      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2">
        {messages.map((message) => (
          <ChatBubble
            key={message.id}
            message={message.message}
            isUser={message.isUser}
            timestamp={message.timestamp}
          />
        ))}
      </div>
      
      {/* Input */}
      <div className="p-4 border-t border-border">
        <div className="flex gap-2">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Type your message..."
            className="flex-1 bg-chat-input border-none"
          />
          <Button onClick={handleSendMessage} size="icon" className="bg-primary hover:bg-primary/90">
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
};