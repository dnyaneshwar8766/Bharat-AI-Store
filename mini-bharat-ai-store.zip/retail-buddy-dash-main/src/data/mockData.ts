// Mock data for FMCG Retail Assistant

export interface Offer {
  id: string;
  product: string;
  discount: number;
  validUntil: string;
  category: string;
}

export interface Transaction {
  id: string;
  date: string;
  product: string;
  quantity: number;
  amount: number;
  retailerId: string;
}

export interface LogisticsBooking {
  id: string;
  date: string;
  vehicle: 'truck' | 'bike';
  route: string;
  status: 'pending' | 'in_transit' | 'delivered';
  distance: number;
}

export interface InventoryItem {
  id: string;
  product: string;
  stock: number;
  expiryDate: string;
  price: number;
  category: string;
}

// Mock data
export const offers: Offer[] = [
  { id: '1', product: 'Coca Cola 500ml', discount: 15, validUntil: '2024-12-31', category: 'Beverages' },
  { id: '2', product: 'Maggi Noodles 2-min', discount: 20, validUntil: '2024-12-25', category: 'Food' },
  { id: '3', product: 'Tide Detergent 1kg', discount: 10, validUntil: '2024-12-30', category: 'Home Care' },
  { id: '4', product: 'Biscuit Parle-G', discount: 25, validUntil: '2024-12-28', category: 'Food' },
];

export const transactions: Transaction[] = [
  { id: '1', date: '2024-12-01', product: 'Coca Cola 500ml', quantity: 50, amount: 2500, retailerId: 'R001' },
  { id: '2', date: '2024-12-02', product: 'Maggi Noodles 2-min', quantity: 100, amount: 1200, retailerId: 'R001' },
  { id: '3', date: '2024-12-03', product: 'Tide Detergent 1kg', quantity: 25, amount: 3750, retailerId: 'R002' },
  { id: '4', date: '2024-12-04', product: 'Biscuit Parle-G', quantity: 80, amount: 800, retailerId: 'R001' },
  { id: '5', date: '2024-12-05', product: 'Coca Cola 500ml', quantity: 75, amount: 3750, retailerId: 'R003' },
  { id: '6', date: '2024-12-06', product: 'Maggi Noodles 2-min', quantity: 60, amount: 720, retailerId: 'R002' },
];

export interface DeliveryOption {
  id: string;
  type: 'truck' | 'bike';
  capacity: string;
  destination: string;
  eta: string;
  cost: string;
  status: string;
}

export const deliveries: DeliveryOption[] = [
  {
    id: "DL1234",
    type: "truck",
    capacity: "200kg",
    destination: "Pune",
    eta: "6 hours",
    cost: "3500",
    status: "Booked"
  },
  {
    id: "DL1235",
    type: "bike",
    capacity: "20kg",
    destination: "Shivajinagar",
    eta: "45 mins",
    cost: "150",
    status: "Booked"
  },
  {
    id: "DL1236",
    type: "truck",
    capacity: "500kg",
    destination: "Delhi",
    eta: "12 hours",
    cost: "8500",
    status: "Available"
  },
  {
    id: "DL1237",
    type: "bike",
    capacity: "15kg",
    destination: "Local Zone B",
    eta: "30 mins",
    cost: "120",
    status: "Available"
  }
];

export const logistics: LogisticsBooking[] = [
  { id: '1', date: '2024-12-07', vehicle: 'truck', route: 'Mumbai to Pune', status: 'delivered', distance: 150 },
  { id: '2', date: '2024-12-08', vehicle: 'bike', route: 'Local delivery - Zone A', status: 'in_transit', distance: 25 },
  { id: '3', date: '2024-12-09', vehicle: 'truck', route: 'Delhi to Gurgaon', status: 'pending', distance: 35 },
];

export const inventory: InventoryItem[] = [
  { id: '1', product: 'Coca Cola 500ml', stock: 500, expiryDate: '2025-03-15', price: 50, category: 'Beverages' },
  { id: '2', product: 'Maggi Noodles 2-min', stock: 200, expiryDate: '2024-12-20', price: 12, category: 'Food' },
  { id: '3', product: 'Tide Detergent 1kg', stock: 150, expiryDate: '2025-06-30', price: 150, category: 'Home Care' },
  { id: '4', product: 'Biscuit Parle-G', stock: 50, expiryDate: '2024-12-15', price: 10, category: 'Food' },
  { id: '5', product: 'Shampoo Head & Shoulders', stock: 75, expiryDate: '2025-08-20', price: 180, category: 'Personal Care' },
];

// Mock API responses
export const getCreditScore = (retailerId: string) => {
  const scores: Record<string, number> = {
    'R001': 750,
    'R002': 680,
    'R003': 820,
  };
  return scores[retailerId] || 650;
};

export const getExpiryAlerts = () => {
  const today = new Date();
  const alertThreshold = 7; // days
  
  return inventory.filter(item => {
    const expiryDate = new Date(item.expiryDate);
    const daysToExpiry = Math.ceil((expiryDate.getTime() - today.getTime()) / (1000 * 3600 * 24));
    return daysToExpiry <= alertThreshold;
  });
};

export const getDemandForecast = () => {
  // Simple demand forecast based on transaction history
  const productDemand: Record<string, number[]> = {};
  
  transactions.forEach(transaction => {
    if (!productDemand[transaction.product]) {
      productDemand[transaction.product] = [];
    }
    productDemand[transaction.product].push(transaction.quantity);
  });
  
  return Object.entries(productDemand).map(([product, quantities]) => ({
    product,
    avgDemand: quantities.reduce((a, b) => a + b, 0) / quantities.length,
    trend: quantities[quantities.length - 1] > quantities[0] ? 'up' : 'down'
  }));
};